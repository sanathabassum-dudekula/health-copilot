
from datetime import date, datetime, timedelta
from secrets import token_hex

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auth import (
    SESSION_COOKIE,
    get_auth_session,
    get_session_user,
    hash_password,
    verify_password,
)
from ..db import get_db
from ..models import AuthSession, FamilyInvitation, FamilyLink, Profile, User

router = APIRouter(prefix="/family", tags=["family"])

PIN_PATTERN = r"^\d{6}$"
MAX_PIN_ATTEMPTS = 5
PIN_LOCKOUT_MINUTES = 15


class FamilyMemberCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    pin: str = Field(pattern=PIN_PATTERN)
    dob: date | None = None
    sex: str | None = Field(default=None, max_length=40)
    age: int | None = Field(default=None, ge=0, le=130)
    blood_group: str | None = Field(default=None, max_length=10)
    allergies_text: str | None = None
    conditions_text: str | None = None
    medicines_text: str | None = None
    previous_records: str | None = None
    emergency_contact_name: str | None = Field(default=None, max_length=120)
    emergency_contact_phone: str | None = Field(default=None, max_length=40)


class FamilyMemberUpdate(BaseModel):
    name: str | None = Field(default=None, max_length=120)
    dob: date | None = None
    sex: str | None = Field(default=None, max_length=40)
    age: int | None = Field(default=None, ge=0, le=130)
    blood_group: str | None = Field(default=None, max_length=10)
    allergies_text: str | None = None
    conditions_text: str | None = None
    medicines_text: str | None = None
    previous_records: str | None = None
    emergency_contact_name: str | None = Field(default=None, max_length=120)
    emergency_contact_phone: str | None = Field(default=None, max_length=40)


class PinRequest(BaseModel):
    pin: str = Field(pattern=PIN_PATTERN)


class PinResetRequest(BaseModel):
    account_password: str = Field(min_length=1)
    new_pin: str = Field(pattern=PIN_PATTERN)




class FamilyInvitationCreate(BaseModel):
    phone_number: str = Field(min_length=8, max_length=24)
    relationship_label: str | None = Field(default=None, max_length=40)


def _invitation_json(invitation: FamilyInvitation) -> dict:
    return {
        "id": invitation.id,
        "phone_number": invitation.phone_number,
        "relationship_label": invitation.relationship_label,
        "status": invitation.status,
        "created_at": invitation.created_at,
        "expires_at": invitation.expires_at,
    }


def _account_owner(
    request: Request,
    db: Session,
) -> tuple[User, Profile, AuthSession]:
    token = request.cookies.get(SESSION_COOKIE)
    session = get_auth_session(token, db)

    if session is None:
        raise HTTPException(
            status_code=401,
            detail="Please sign in to manage family profiles.",
        )

    owner_user = db.get(User, session.user_id)
    if owner_user is None or owner_user.profile is None:
        raise HTTPException(status_code=401, detail="Account profile not found.")

    return owner_user, owner_user.profile, session


def _new_oid(db: Session) -> str:
    for _ in range(10):
        oid = "CM-" + token_hex(16).upper()
        exists = db.scalar(select(Profile.id).where(Profile.oid == oid))
        if exists is None:
            return oid

    raise HTTPException(
        status_code=503,
        detail="Could not generate a unique profile ID",
    )


def _member_json(member: Profile) -> dict:
    calculated_age = None

    if member.dob:
        today = date.today()
        calculated_age = today.year - member.dob.year - (
            (today.month, today.day) < (member.dob.month, member.dob.day)
        )

    return {
        "oid": member.oid,
        "name": member.name,
        "dob": member.dob,
        "sex": member.sex,
        "age": calculated_age if member.dob else member.age,
        "blood_group": member.blood_group,
        "allergies_text": member.allergies_text,
        "conditions_text": member.conditions_text,
        "medicines_text": member.medicines_text,
        "previous_records": member.previous_records,
        "emergency_contact_name": member.emergency_contact_name,
        "emergency_contact_phone": member.emergency_contact_phone,
        "has_pin": bool(member.access_pin_hash),
    }


def _get_linked_member(
    oid: str,
    owner: Profile,
    db: Session,
) -> Profile:
    member = db.scalar(select(Profile).where(Profile.oid == oid))

    if member is None:
        raise HTTPException(status_code=404, detail="Family member not found")

    link = db.scalar(
        select(FamilyLink).where(
            FamilyLink.owner_user_id == owner.user_id,
            FamilyLink.member_user_id == member.user_id,
        )
    )

    if link is None:
        raise HTTPException(
            status_code=404,
            detail="Family member not linked to this account",
        )

    return member


def _clear_pin_failures(member: Profile) -> None:
    member.pin_failed_attempts = 0
    member.pin_locked_until = None


@router.get("")
def list_family(
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, _ = _account_owner(request, db)

    links = db.scalars(
        select(FamilyLink).where(
            FamilyLink.owner_user_id == owner.user_id
        )
    ).all()

    members = []

    for link in links:
        member = db.scalar(
            select(Profile).where(Profile.user_id == link.member_user_id)
        )

        if member is not None:
            members.append(_member_json(member))

    return {"members": members}


@router.get("/active")
def get_active_family_profile(
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, session = _account_owner(request, db)

    # No family profile is selected: the account owner is active.
    if session.active_profile_id is None:
        return {
            "type": "owner",
            "active_profile": {
                "oid": owner.oid,
                "name": owner.name,
            },
        }

    member = db.get(Profile, session.active_profile_id)

    if member is None:
        session.active_profile_id = None
        db.commit()
        raise HTTPException(
            status_code=403,
            detail="Selected family profile is unavailable. Please select it again.",
        )

    # Confirm that the selected profile is still linked to this owner.
    _get_linked_member(member.oid, owner, db)

    return {
        "type": "family",
        "active_profile": _member_json(member),
    }

@router.post("", status_code=201)
def create_family_member(
    body: FamilyMemberCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, _ = _account_owner(request, db)

    values = body.model_dump()
    pin = values.pop("pin")
    name = (values.get("name") or "").strip()

    if not name:
        raise HTTPException(status_code=422, detail="Name cannot be blank")

    values["name"] = name

    for field in (
        "sex",
        "blood_group",
        "allergies_text",
        "conditions_text",
        "medicines_text",
        "previous_records",
        "emergency_contact_name",
        "emergency_contact_phone",
    ):
        if isinstance(values.get(field), str):
            values[field] = values[field].strip() or None

    member_user = User()
    member_profile = Profile(
        oid=_new_oid(db),
        access_pin_hash=hash_password(pin),
        pin_failed_attempts=0,
        **values,
    )

    member_user.profile = member_profile
    db.add(member_user)

    try:
        db.flush()

        db.add(
            FamilyLink(
                owner_user_id=owner.user_id,
                member_user_id=member_user.id,
            )
        )

        db.commit()
        db.refresh(member_profile)

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Could not create the family member",
        )

    return _member_json(member_profile)




@router.post("/invitations", status_code=201)
def create_family_invitation(
    body: FamilyInvitationCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    owner_user, _, _ = _account_owner(request, db)

    # Accept international-style numbers containing digits and common
    # formatting characters; store only the normalized leading plus/digits.
    raw_phone = body.phone_number.strip()
    if not all(ch.isdigit() or ch in "+ ()-." for ch in raw_phone):
        raise HTTPException(status_code=422, detail="Enter a valid phone number.")

    digits = "".join(ch for ch in raw_phone if ch.isdigit())
    if not 8 <= len(digits) <= 15:
        raise HTTPException(status_code=422, detail="Enter a valid phone number.")

    normalized_phone = ("+" if raw_phone.startswith("+") else "") + digits
    now = datetime.utcnow()

    invitation = FamilyInvitation(
        owner_user_id=owner_user.id,
        phone_number=normalized_phone,
        relationship_label=(
            body.relationship_label.strip()
            if body.relationship_label and body.relationship_label.strip()
            else None
        ),
        status="pending",
        expires_at=now + timedelta(days=7),
    )
    db.add(invitation)
    db.commit()
    db.refresh(invitation)

    result = _invitation_json(invitation)
    result["message"] = (
        "Invitation saved as pending. No SMS was sent; phone verification "
        "and recipient acceptance are not configured yet."
    )
    return result


@router.get("/invitations")
def list_family_invitations(
    request: Request,
    db: Session = Depends(get_db),
):
    owner_user, _, _ = _account_owner(request, db)
    now = datetime.utcnow()

    invitations = db.scalars(
        select(FamilyInvitation)
        .where(FamilyInvitation.owner_user_id == owner_user.id)
        .order_by(FamilyInvitation.id.desc())
    ).all()

    result = []
    for invitation in invitations:
        if invitation.status == "pending" and invitation.expires_at <= now:
            invitation.status = "expired"
        result.append(_invitation_json(invitation))

    db.commit()
    return result


@router.delete("/invitations/{invitation_id}")
def cancel_family_invitation(
    invitation_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    owner_user, _, _ = _account_owner(request, db)

    invitation = db.scalar(
        select(FamilyInvitation).where(
            FamilyInvitation.id == invitation_id,
            FamilyInvitation.owner_user_id == owner_user.id,
        )
    )
    if invitation is None:
        raise HTTPException(status_code=404, detail="Invitation not found.")

    if invitation.status != "pending":
        raise HTTPException(
            status_code=409,
            detail="Only pending invitations can be cancelled.",
        )

    invitation.status = "cancelled"
    db.commit()
    return {"ok": True, "id": invitation.id, "status": invitation.status}


@router.get("/{oid}")
def get_family_member(
    oid: str,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, _ = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)
    return _member_json(member)


@router.put("/{oid}")
def update_family_member(
    oid: str,
    body: FamilyMemberUpdate,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, _ = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)
    changes = body.model_dump(exclude_unset=True)

    for field, value in changes.items():
        if field == "name":
            if value is None or not value.strip():
                raise HTTPException(
                    status_code=422,
                    detail="Name cannot be blank",
                )
            value = value.strip()

        elif field in {
            "sex",
            "blood_group",
            "allergies_text",
            "conditions_text",
            "medicines_text",
            "previous_records",
            "emergency_contact_name",
            "emergency_contact_phone",
        }:
            if isinstance(value, str):
                value = value.strip() or None

        setattr(member, field, value)

    db.commit()
    db.refresh(member)

    return _member_json(member)


@router.post("/{oid}/set-pin")
def set_legacy_pin(
    oid: str,
    body: PinRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, _ = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)

    if member.access_pin_hash:
        raise HTTPException(
            status_code=409,
            detail="This member already has a PIN. Use the PIN reset option.",
        )

    member.access_pin_hash = hash_password(body.pin)
    _clear_pin_failures(member)

    db.commit()

    return {"message": "Family member PIN set successfully."}


@router.post("/{oid}/unlock")
def unlock_family_member(
    oid: str,
    body: PinRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, session = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)

    if not member.access_pin_hash:
        raise HTTPException(
            status_code=409,
            detail="PIN setup is required before opening this profile.",
        )

    now = datetime.utcnow()

    if member.pin_locked_until and member.pin_locked_until > now:
        remaining = int(
            (member.pin_locked_until - now).total_seconds()
        ) + 1

        raise HTTPException(
            status_code=429,
            detail={
                "message": "Too many incorrect PIN attempts. Try again later.",
                "retry_after_seconds": remaining,
            },
        )

    if member.pin_locked_until and member.pin_locked_until <= now:
        _clear_pin_failures(member)

    if not verify_password(body.pin, member.access_pin_hash):
        member.pin_failed_attempts = (member.pin_failed_attempts or 0) + 1

        if member.pin_failed_attempts >= MAX_PIN_ATTEMPTS:
            member.pin_locked_until = now + timedelta(
                minutes=PIN_LOCKOUT_MINUTES
            )
            db.commit()

            raise HTTPException(
                status_code=429,
                detail="Five incorrect attempts. This profile is locked for 15 minutes.",
            )

        remaining_attempts = MAX_PIN_ATTEMPTS - member.pin_failed_attempts
        db.commit()

        raise HTTPException(
            status_code=401,
            detail=f"Incorrect PIN. {remaining_attempts} attempts remaining.",
        )

    _clear_pin_failures(member)
    session.active_profile_id = member.id
    db.commit()

    return {
        "message": "Family profile unlocked successfully.",
        "active_profile": _member_json(member),
    }


@router.post("/{oid}/reset-pin")
def reset_family_pin(
    oid: str,
    body: PinResetRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    owner_user, owner, session = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)

    if not verify_password(
        body.account_password,
        owner_user.password_hash,
    ):
        raise HTTPException(
            status_code=401,
            detail="Account password is incorrect.",
        )

    member.access_pin_hash = hash_password(body.new_pin)
    _clear_pin_failures(member)

    if session.active_profile_id == member.id:
        session.active_profile_id = None

    db.commit()

    return {
        "message": "PIN reset successfully. The family profile remains locked."
    }


@router.post("/switch-to-owner")
def switch_to_owner(
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, session = _account_owner(request, db)

    session.active_profile_id = None
    db.commit()

    return {
        "message": "Switched to the main account profile.",
        "active_profile": {
            "oid": owner.oid,
            "name": owner.name,
        },
    }


@router.delete("/{oid}", status_code=204)
def unlink_family_member(
    oid: str,
    request: Request,
    db: Session = Depends(get_db),
):
    _, owner, session = _account_owner(request, db)
    member = _get_linked_member(oid, owner, db)

    link = db.scalar(
        select(FamilyLink).where(
            FamilyLink.owner_user_id == owner.user_id,
            FamilyLink.member_user_id == member.user_id,
        )
    )

    # If this member is currently selected, return the session to the owner.
    if session.active_profile_id == member.id:
        session.active_profile_id = None

    # Unlink only; do not delete the member or their medical records.
    db.delete(link)
    db.commit()

    return None
