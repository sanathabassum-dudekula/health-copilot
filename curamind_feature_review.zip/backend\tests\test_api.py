﻿"""End-to-end through the real ingestion pipeline with the LLM stubbed."""
import io
import base64
import uuid

import pytest

from fastapi.testclient import TestClient
from fhir.resources.R4B.bundle import Bundle
from PIL import Image

from app.ingestion import graph, summarize
from app.ingestion.schemas import DocumentExtraction, Summary, DocumentClassification
from app.main import app
from app.routers import documents as document_routes


@pytest.fixture(autouse=True)
def mock_document_storage(monkeypatch, tmp_path):
    # Keep API tests independent of real S3 credentials and network access.
    stored = {}

    def fake_upload(key, data, content_type):
        stored[key] = data

    def fake_download(key, destination):
        from pathlib import Path
        Path(destination).write_bytes(stored[key])

    monkeypatch.setattr(document_routes, "store_file", fake_upload)
    monkeypatch.setattr(document_routes, "delete_file", lambda key: stored.pop(key, None))

    class FakeS3Body:
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

    class FakeS3Client:
        def get_object(self, Bucket, Key):
            if Key not in stored:
                raise KeyError(Key)
            return {"Body": FakeS3Body(stored[Key])}

    monkeypatch.setattr(
        document_routes, "get_s3_client", lambda: FakeS3Client()
    )

    from app.ingestion import prepare
    monkeypatch.setattr(prepare, "download_file", fake_download)


EXTRACTION = DocumentExtraction.model_validate({
    "doc_type": "lab_report", "doc_date": "2026-09-01", "patient_name": "Sunita Devi", "facility": "Lab X",
    "lab_results": [
        {"test_name": "Hemoglobin", "value": "10.8", "unit": "g/dL", "source_text": "Hb 10.8", "confidence": 0.9},
        {"test_name": "Potassium", "value": "6.9", "unit": "mmol/L", "source_text": "K 6.9", "confidence": 0.9}],
    "medications": [{"name": "Dolo-650", "dose_pattern": "1-0-1", "duration": "5 days",
                     "source_text": "Dolo 650 1-0-1 x5d", "confidence": 0.8}],
    "diagnoses": [{"name": "Anaemia", "source_text": "Anaemia", "confidence": 0.9}]})
SUMMARY = Summary(headline="Your blood test", key_points=["One value is low."], abnormal_explanations=[
    {"test": "Haemoglobin", "value": "10.8 g/dL", "status": "Low", "what_it_means": "Lower than usual.",
     "common_reasons": "Many things.", "question_for_doctor": "Why is it low?"},
    {"test": "Invented Test", "value": "1", "status": "High", "what_it_means": "x", "common_reasons": "x",
     "question_for_doctor": "x"}])


class FakeLLM:
    def __init__(self, out):
        self.out = out

    def invoke(self, *_):
        return self.out



def _accept_medical_document(*args, **kwargs):
    return DocumentClassification(
        is_medical=True,
        confidence=0.99,
        reason="Accepted by the test classifier mock.",
    )

def _png():
    buf = io.BytesIO()
    Image.new("RGB", (50, 50), "white").save(buf, "PNG")
    return buf.getvalue()


def _visit():
    return {"X-Visit": str(uuid.uuid4())}


def _registered_owner():
    client = TestClient(app, headers=_visit())

    response = client.post(
        "/auth/register",
        json={
            "email": f"family-test-{uuid.uuid4().hex}@example.com",
            "password": "TestPassword123!",
            "name": "Test Owner",
        },
    )

    assert response.status_code == 200, response.text
    return client



def test_health_assistant_uses_language_and_profile_context(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    captured = {}

    class FakeChat:
        calls = 0

        def invoke(self, messages):
            captured["messages"] = messages
            self.calls += 1
            if self.calls > 1:
                assert messages[-3].content == "Could these symptoms be an allergic reaction?"
                assert messages[-1].content == "Is it still there?"
            return AIMessage(content="à®‡à®¨à¯à®¤ à®®à®°à¯à®¨à¯à®¤à¯ à®’à®µà¯à®µà®¾à®®à¯ˆà®¯à¯ˆ à®à®±à¯à®ªà®Ÿà¯à®¤à¯à®¤à®²à®¾à®®à¯; à®®à®°à¯à®¤à¯à®¤à¯à®µà®°à®¿à®Ÿà®®à¯ à®•à¯‡à®³à¯à®™à¯à®•à®³à¯.")

    fake_chat = FakeChat()
    monkeypatch.setattr(assistant, "chat_model", lambda *args: fake_chat)
    with TestClient(app, headers=_visit()) as c:
        c.put("/profile", json={"allergies_text": "Penicillin"})
        response = c.post(
            "/assistant/chat",
            json={
                "message": "Could these symptoms be an allergic reaction?",
                "language": "ta",
            },
        )
        follow_up = c.post(
            "/assistant/chat",
            json={"message": "Is it still there?", "language": "ta"},
        )
        saved_history = c.get("/assistant/history")

    assert response.status_code == 200
    assert "à®’à®µà¯à®µà®¾à®®à¯ˆ" in response.json()["answer"]
    assert follow_up.status_code == 200
    assert len(saved_history.json()) == 4
    assert "Respond in Tamil" in captured["messages"][0].content
    assert "Penicillin" in captured["messages"][0].content


def test_health_assistant_uses_page_context_without_saving_it(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    captured = {}

    class ContextChat:
        def invoke(self, messages):
            captured["messages"] = messages
            return AIMessage(content="This page shows your recent health overview.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: ContextChat())
    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/assistant/chat",
            json={
                "message": "Can you explain this page?",
                "language": "en",
                "page_context": "Health page: 2 documents, 1 result to review.",
            },
        )
        history = client.get("/assistant/history")

    assert response.status_code == 200
    assert "Health page: 2 documents, 1 result to review." in captured["messages"][0].content
    assert [message["content"] for message in history.json()] == [
        "Can you explain this page?",
        "This page shows your recent health overview.",
    ]


def test_health_assistant_retries_transient_model_errors(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.ingestion import llm
    from app.routers import assistant

    class TemporaryModelError(Exception):
        code = 503

    class FlakyChat:
        calls = 0

        def invoke(self, _messages):
            self.calls += 1
            if self.calls == 1:
                try:
                    raise TemporaryModelError("Model is temporarily unavailable")
                except TemporaryModelError as error:
                    raise RuntimeError("The provider wrapped a transient failure") from error
            return AIMessage(content="I can help with general health information.")

    fake_chat = FlakyChat()
    monkeypatch.setattr(assistant, "chat_model", lambda *args: fake_chat)
    monkeypatch.setattr(llm.time, "sleep", lambda _seconds: None)

    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/assistant/chat",
            json={"message": "Can you help me understand my health records?"},
        )

    assert response.status_code == 200
    assert fake_chat.calls == 2


def test_document_classifier_retries_transient_model_errors(monkeypatch):
    from app.ingestion import classify, llm

    class TemporaryModelError(Exception):
        code = 503

    class FlakyStructured:
        calls = 0

        def invoke(self, _messages):
            self.calls += 1
            if self.calls == 1:
                raise TemporaryModelError("Model is temporarily unavailable")
            return DocumentClassification(
                is_medical=True,
                confidence=0.99,
                reason="Medical report.",
            )

    fake_model = FlakyStructured()
    monkeypatch.setattr(classify, "prepare_file", lambda *_args, **_kwargs: ([], "report text"))
    monkeypatch.setattr(classify, "structured", lambda *_args: fake_model)
    monkeypatch.setattr(llm.time, "sleep", lambda _seconds: None)

    result = classify.classify_document(_png(), "image/png")

    assert result.is_medical
    assert fake_model.calls == 2


def test_health_assistant_uses_uploaded_document_context_without_saving_it(monkeypatch):
    from langchain_core.messages import AIMessage
    from sqlalchemy import select

    from app.db import SessionLocal
    from app.models import Document, Profile, Visit
    from app.routers import assistant

    captured = {}

    class ContextChat:
        def invoke(self, messages):
            captured["messages"] = messages
            return AIMessage(content="The report lists potassium at 6.9 mmol/L.")

    monkeypatch.setattr(assistant, "chat_model", lambda *_args: ContextChat())
    visit = _visit()
    with TestClient(app, headers=visit) as client:
        client.get("/profile")
        with SessionLocal() as db:
            profile = db.scalar(
                select(Profile)
                .join(Visit, Visit.user_id == Profile.user_id)
                .where(Visit.token == visit["X-Visit"])
            )
            document = Document(
                profile_id=profile.id,
                doc_type="lab_report",
                status="done",
                source="upload",
                review_status="pending",
                extraction={
                    "doc_type": "lab_report",
                    "lab_results": [{
                        "test_name": "Potassium",
                        "value": "6.9",
                        "unit": "mmol/L",
                        "source_text": "K 6.9",
                        "confidence": 0.9,
                    }],
                },
            )
            db.add(document)
            db.commit()
            document_id = document.id

        response = client.post(
            "/assistant/chat",
            json={
                "message": "Can you explain my report?",
                "document_id": document_id,
            },
        )
        history = client.get("/assistant/history")

    assert response.status_code == 200
    assert "Potassium" in captured["messages"][0].content
    assert "not yet confirmed" in captured["messages"][0].content
    assert "K 6.9" not in captured["messages"][0].content
    assert all("K 6.9" not in message["content"] for message in history.json())


def test_health_assistant_proposes_explicit_reminder_for_confirmation(monkeypatch):
    from datetime import datetime

    from langchain_core.messages import AIMessage
    from app.routers import assistant

    class ReminderChat:
        def invoke(self, _messages):
            return AIMessage(content="I can help you remember your appointment.")

    class ReminderModel:
        def invoke(self, _messages):
            return assistant.AssistantReminderProposal(
                title="Doctor appointment",
                details="Bring the lab report.",
                due_at=datetime(2026, 10, 19, 9, 0),
                category="appointment",
            )

    monkeypatch.setattr(assistant, "chat_model", lambda *_args: ReminderChat())
    monkeypatch.setattr(assistant, "structured", lambda *_args: ReminderModel())
    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/assistant/chat",
            json={
                "message": "Remind me about my appointment tomorrow at 9 AM.",
                "local_now": "2026-10-18T15:00:00+05:30",
            },
        )

    assert response.status_code == 200
    assert response.json()["reminder_proposal"] == {
        "title": "Doctor appointment",
        "details": "Bring the lab report.",
        "due_at": "2026-10-19T09:00:00+05:30",
        "category": "appointment",
    }
    assert response.json()["reminder_proposal_error"] is False


def test_health_assistant_prepares_separate_spoken_language(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    class LanguageChat:
        def invoke(self, messages):
            if "Translate the following health assistant response" in messages[0].content:
                return AIMessage(content="à°†à°°à±‹à°—à±à°¯à°¾à°¨à°¿à°•à°¿ à°¸à°‚à°¬à°‚à°§à°¿à°‚à°šà°¿à°¨ à°¸à°¾à°§à°¾à°°à°£ à°¸à°®à°¾à°šà°¾à°°à°‚.")
            return AIMessage(content="General health information.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: LanguageChat())
    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/assistant/chat",
            json={
                "message": "How can I stay hydrated?",
                "language": "en",
                "voice_language": "te",
            },
        )

    assert response.status_code == 200
    assert response.json()["answer"] == "General health information."
    assert response.json()["spoken_answer"] == "à°†à°°à±‹à°—à±à°¯à°¾à°¨à°¿à°•à°¿ à°¸à°‚à°¬à°‚à°§à°¿à°‚à°šà°¿à°¨ à°¸à°¾à°§à°¾à°°à°£ à°¸à°®à°¾à°šà°¾à°°à°‚."
    assert response.json()["voice_translation_error"] is False


def test_health_assistant_history_is_private_and_deletable(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    monkeypatch.setattr(
        assistant,
        "chat_model",
        lambda *args: FakeLLM(AIMessage(content="General information only.")),
    )
    first_visit = _visit()
    second_visit = _visit()
    with TestClient(app, headers=first_visit) as first, TestClient(app, headers=second_visit) as second:
        first.post("/assistant/chat", json={"message": "Remember this detail."})
        assert len(first.get("/assistant/history").json()) == 2
        assert first.get("/profile/timeline").json() == []
        assert second.get("/assistant/history").json() == []
        assert first.delete("/assistant/history").status_code == 204
        assert first.get("/assistant/history").json() == []


def test_health_assistant_conversations_have_separate_history(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    captured = []

    class ConversationChat:
        def invoke(self, messages):
            captured.append(messages)
            return AIMessage(content="I can share general health information.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: ConversationChat())
    with TestClient(app, headers=_visit()) as first:
        first_chat = first.post("/assistant/conversations").json()
        second_chat = first.post("/assistant/conversations").json()
        first.post("/assistant/chat", json={
            "message": "My rash started yesterday.",
            "conversation_id": first_chat["id"],
        })
        first.post("/assistant/chat", json={
            "message": "I have a headache.",
            "conversation_id": second_chat["id"],
        })

        first_history = first.get(
            f"/assistant/history?conversation_id={first_chat['id']}"
        ).json()
        second_history = first.get(
            f"/assistant/history?conversation_id={second_chat['id']}"
        ).json()
        conversations = first.get("/assistant/conversations").json()

        with TestClient(app, headers=_visit()) as other:
            assert other.get(
                f"/assistant/history?conversation_id={first_chat['id']}"
            ).status_code == 404
            assert other.delete(
                f"/assistant/conversations/{first_chat['id']}"
            ).status_code == 404

    assert [message["content"] for message in first_history] == [
        "My rash started yesterday.",
        "I can share general health information.",
    ]
    assert [message["content"] for message in second_history] == [
        "I have a headache.",
        "I can share general health information.",
    ]
    assert "My rash started yesterday." not in str(captured[1])
    assert conversations[0]["id"] == second_chat["id"]


def test_health_assistant_accepts_image_attachment_without_saving_image(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    captured = {}

    class ImageChat:
        def invoke(self, messages):
            captured["messages"] = messages
            return AIMessage(content="I can share general information about this image.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: ImageChat())
    with TestClient(app, headers=_visit()) as c:
        response = c.post(
            "/assistant/chat",
            json={
                "message": "What should I know about this?",
                "images": [{
                    "mime_type": "image/png",
                    "data_base64": base64.b64encode(_png()).decode("ascii"),
                }],
            },
        )
        history = c.get("/assistant/history").json()

    assert response.status_code == 200
    user_message = next(message for message in captured["messages"][-1].content if message["type"] == "text")
    assert user_message["text"] == "What should I know about this?"
    assert any(block["type"] == "image" for block in captured["messages"][-1].content)
    assert "image files are not saved" in history[-2]["content"]


def test_health_assistant_rejects_invalid_image_and_sets_health_scope(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    captured = {}

    class ScopeChat:
        def invoke(self, messages):
            captured["system"] = messages[0].content
            return AIMessage(content="I can help with health questions.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: ScopeChat())
    with TestClient(app, headers=_visit()) as c:
        invalid = c.post(
            "/assistant/chat",
            json={"message": "Check this", "images": [{"mime_type": "image/png", "data_base64": "not-image"}]},
        )
        c.post("/assistant/chat", json={"message": "Can you write a poem?"})

    assert invalid.status_code == 422
    assert "Only answer questions related to human health" in captured["system"]
    assert "Do not diagnose fractures" in captured["system"]


def test_health_assistant_rejects_blank_message():
    with TestClient(app, headers=_visit()) as c:
        response = c.post("/assistant/chat", json={"message": "   "})
    assert response.status_code == 422


def test_reminders_support_recurring_and_linked_family_profiles():
    with _registered_owner() as owner:
        created = owner.post(
            "/family",
            json={"name": "Parent", "pin": "123456"},
        )
        assert created.status_code == 201, created.text
        family = created.json()

        unlocked = owner.post(
            f"/family/{family['oid']}/unlock",
            json={"pin": "123456"},
        )
        assert unlocked.status_code == 200, unlocked.text

        response = owner.post(
            f"/reminders?profile_oid={family['oid']}",
            json={
                "title": "Review prescription",
                "spoken_title": "Prescription review",
                "spoken_details": "Check the confirmed directions.",
                "due_at": "2026-10-17T09:00:00+05:30",
                "recurrence": "monthly",
            },
        )
        assert response.status_code == 201
        reminder = response.json()
        assert reminder["profile_oid"] == family["oid"]
        assert reminder["spoken_title"] == "Prescription review"
        assert reminder["spoken_details"] == "Check the confirmed directions."
        assert reminder["due_at"] == "2026-10-17T03:30:00+00:00"

        completed = owner.post(
            f"/reminders/{reminder['id']}/complete?profile_oid={family['oid']}"
        )
        assert completed.status_code == 200
        assert completed.json()["status"] == "pending"
        assert completed.json()["due_at"] == "2026-11-17T03:30:00+00:00"

        with TestClient(app, headers=_visit()) as other:
            denied = other.get(f"/reminders?profile_oid={family['oid']}")
        assert denied.status_code == 404


def test_profile_saves_separate_voice_language_and_voice_reminder_preference():
    with TestClient(app, headers=_visit()) as client:
        response = client.put(
            "/profile",
            json={
                "preferred_language": "en",
                "preferred_voice_language": "te",
                "voice_reminders_enabled": True,
            },
        )
        assert response.status_code == 200
        assert response.json()["language"] == "en"
        assert response.json()["voice_language"] == "te"
        assert response.json()["voice_reminders_enabled"] is True
        assert client.get("/profile").json()["voice_language"] == "te"


def test_routine_suggestions_keep_medicine_schedules_confirmed_and_separate(monkeypatch):
    from sqlalchemy import select

    from app.db import SessionLocal
    from app.models import Document, Medication, Profile, Visit
    from app.routers import reminders

    captured = {}

    class StubStructured:
        def invoke(self, messages):
            captured["prompt"] = messages[0]["content"]
            return reminders.RoutinePlan(
                suggestions=[
                    reminders.RoutineSuggestion(
                        title="Take a gentle stretch break",
                        details="Try a comfortable stretch if it feels suitable.",
                        spoken_title="Stretch break",
                        spoken_details="A gentle stretch break.",
                        local_time="15:00",
                        category="wellness",
                    )
                ],
                note="These are general suggestions to review.",
            )

    monkeypatch.setattr(reminders, "structured", lambda *_: StubStructured())
    visit = _visit()
    with TestClient(app, headers=visit) as client:
        client.get("/profile")
        with SessionLocal() as db:
            profile = db.scalar(
                select(Profile)
                .join(Visit, Visit.user_id == Profile.user_id)
                .where(Visit.token == visit["X-Visit"])
            )
            confirmed = Document(
                profile_id=profile.id,
                status="done",
                source="upload",
                review_status="confirmed",
            )
            pending = Document(
                profile_id=profile.id,
                status="done",
                source="upload",
                review_status="pending",
            )
            db.add_all([confirmed, pending])
            db.flush()
            db.add_all([
                Medication(
                    profile_id=profile.id,
                    document_id=confirmed.id,
                    brand_name="Confirmed medicine",
                    timing="after breakfast",
                ),
                Medication(
                    profile_id=profile.id,
                    document_id=pending.id,
                    brand_name="Unreviewed medicine",
                    timing="morning",
                ),
            ])
            db.commit()

        schedule_response = client.get("/reminders/confirmed-prescriptions")
        response = client.post(
            "/reminders/suggestions",
            json={"written_language": "en", "voice_language": "hi"},
        )

    assert response.status_code == 200
    result = response.json()
    assert result["suggestions"][0]["category"] == "wellness"
    assert result["suggestions"][0]["local_time"] == "15:00"
    assert schedule_response.status_code == 200
    assert [item["name"] for item in schedule_response.json()] == [
        "Confirmed medicine"
    ]
    assert "Do not provide medication reminders" in captured["prompt"]
    assert "Hindi" in captured["prompt"]


def test_insights_are_cautious_and_do_not_create_risk_scores():
    visit = _visit()
    with TestClient(app, headers=visit) as client:
        response = client.get("/insights")
    assert response.status_code == 200
    result = response.json()
    assert result["flagged_results"] == []
    assert result["trends"] == []
    assert "risk_score" not in result
    assert result["wellness"]


def test_insights_include_same_test_trends_and_document_follow_up():
    from datetime import date
    from app.db import SessionLocal
    from app.models import Document, Observation, Visit

    visit = _visit()
    with TestClient(app, headers=visit) as client:
        client.get("/profile")
        with SessionLocal() as db:
            visit_record = db.get(Visit, visit["X-Visit"])
            profile = visit_record.user.profile
            document = Document(
                profile_id=profile.id,
                status="done",
                review_status="confirmed",
                source="upload",
                doc_date=date(2026, 8, 2),
                extraction={"follow_up": "Discuss this result with your clinician."},
                summary={"next_steps": ["Bring the report to your appointment."]},
            )
            db.add(document)
            db.flush()
            db.add_all([
                Observation(
                    profile_id=profile.id,
                    document_id=document.id,
                    display_name="Hemoglobin",
                    value_num=10.0,
                    unit="g/dL",
                    interpretation="L",
                    effective_at=date(2026, 7, 1),
                ),
                Observation(
                    profile_id=profile.id,
                    document_id=document.id,
                    display_name="Hemoglobin",
                    value_num=11.0,
                    unit="g/dL",
                    interpretation="L",
                    effective_at=date(2026, 8, 2),
                ),
            ])
            db.commit()
        result = client.get("/insights").json()
    assert result["trends"][0]["direction"] == "increased"
    assert result["trends"][0]["previous_value"] == 10.0
    assert result["trends"][0]["latest_value"] == 11.0
    assert "Discuss this result with your clinician." in result["follow_ups"]
    assert "Bring the report to your appointment." in result["follow_ups"]


def test_assistant_can_use_only_a_linked_family_profiles_history(monkeypatch):
    from langchain_core.messages import AIMessage
    from app.routers import assistant

    class FamilyChat:
        def invoke(self, messages):
            return AIMessage(content="General health information.")

    monkeypatch.setattr(assistant, "chat_model", lambda *args: FamilyChat())
    with _registered_owner() as owner:
        created = owner.post(
            "/family",
            json={"name": "Child", "pin": "123456"},
        )
        assert created.status_code == 201, created.text
        member = created.json()

        unlocked = owner.post(
            f"/family/{member['oid']}/unlock",
            json={"pin": "123456"},
        )
        assert unlocked.status_code == 200, unlocked.text

        conversation = owner.post(
            f"/assistant/conversations?profile_oid={member['oid']}"
        ).json()
        response = owner.post("/assistant/chat", json={
            "message": "How can I prepare for the visit?",
            "conversation_id": conversation["id"],
            "profile_oid": member["oid"],
        })
        assert response.status_code == 200
        assert len(owner.get(
            f"/assistant/history?profile_oid={member['oid']}"
        ).json()) == 2
        with TestClient(app, headers=_visit()) as other:
            denied = other.get(
                f"/assistant/history?profile_oid={member['oid']}"
            )
    assert denied.status_code == 403


def test_full_flow(monkeypatch):
    from app.db import SessionLocal
    from app.models import Visit
    from app.routers.assistant import _health_context
    from app.routers import documents
    monkeypatch.setattr(
        documents, 'classify_document', _accept_medical_document
    )
    monkeypatch.setattr(graph, "structured", lambda *a: FakeLLM(EXTRACTION))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))
    headers = _visit()
    with TestClient(app, headers=headers) as c:
        assert c.post("/documents", files={"file": ("a.txt", b"x", "text/plain")}).status_code == 415

        r = c.post("/documents", files={"file": ("a.png", _png(), "image/png")})
        d = c.get(f"/documents/{r.json()['id']}").json()
        assert d["status"] == "done", d["extraction"]
        assert d["review_status"] == "pending"
        assert d["summary"] is None
        assert c.get(f"/documents/{d['id']}/summary").status_code == 409
        assert c.get("/profile").json()["conditions"] == []
        assert c.get("/profile/timeline").json()[0]["type"] == "document_pending"
        assert c.get("/insights").json()["flagged_results"] == []
        pending_bundle = c.get("/profile/fhir").json()
        assert not any(
            entry["resource"]["resourceType"] == "Composition"
            for entry in pending_bundle["entry"]
        )
        with SessionLocal() as db:
            visit_record = db.get(Visit, headers["X-Visit"])
            context = _health_context(visit_record.user.profile, db)
        assert context["recorded_conditions"] == []
        assert context["recorded_current_medicines"] == []
        assert context["recent_test_results"] == []
        assert c.post(
            f"/documents/{d['id']}/review",
            json={"decision": "confirmed"},
        ).json()["review_status"] == "confirmed"
        d = c.get(f"/documents/{d['id']}").json()

        hb = next(o for o in d["observations"] if o["loinc_code"] == "718-7")
        assert hb["interpretation"] == "L"  # female range 12-15
        assert next(o for o in d["observations"] if o["display_name"] == "Potassium")["interpretation"] == "HH"
        assert d["medications"][0]["salt"] == "Paracetamol" and d["medications"][0]["per_day"] == 2

        tests = [e["test"] for e in d["summary"]["abnormal_explanations"]]
        assert tests[0] == "Potassium" and "Haemoglobin" in tests and "Invented Test" not in tests
        assert "contact a doctor promptly" in d["summary"]["abnormal_explanations"][0]["what_it_means"]

        assert c.get(f"/documents/{d['id']}/file").status_code == 200
        prof = c.get("/profile").json()
        assert prof["conditions"] == ["Anaemia"]
        kinds = {i["type"] for i in c.get("/profile/timeline").json()}
        assert {"document", "abnormal_result", "diagnosis", "medicine_started"} <= kinds
        only = c.get("/profile/timeline?types=diagnoses").json()
        assert {i["type"] for i in only} == {"diagnosis"}

        assert c.post("/abha/import").status_code == 409
        assert c.post("/abha/link", json={"abha": "bad"}).status_code == 422
        otp = c.post("/abha/link", json={"abha": "12-3456-7890-1234"}).json()["demo_otp"]
        assert c.post("/abha/verify", json={"otp": "000000"}).status_code == 401
        assert c.post("/abha/verify", json={"otp": otp}).status_code == 200
        imported = c.post("/abha/import").json()["imported_document_ids"]
        assert len(imported) == 2
        for imported_id in imported:
            assert c.post(
                f"/documents/{imported_id}/review",
                json={"decision": "confirmed"},
            ).status_code == 200
        assert c.post("/abha/import").json()["imported_document_ids"] == []  # idempotent
        assert any(i["source"] == "abdm" for i in c.get("/profile/timeline").json())

        Bundle.model_validate(c.get("/profile/fhir").json())
        assert c.delete("/profile").status_code == 204
        assert c.get("/documents").json() == []  # data gone; a fresh demo profile is recreated


def test_rejecting_extraction_removes_unverified_health_facts(monkeypatch):
    from app.routers import documents

    monkeypatch.setattr(
        documents, "classify_document", _accept_medical_document
    )
    monkeypatch.setattr(graph, "structured", lambda *a: FakeLLM(EXTRACTION))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))

    with TestClient(app, headers=_visit()) as client:
        uploaded = client.post(
            "/documents",
            files={"file": ("report.png", _png(), "image/png")},
        )
        doc_id = uploaded.json()["id"]

        rejected = client.post(
            f"/documents/{doc_id}/review",
            json={"decision": "rejected"},
        )
        assert rejected.status_code == 200
        assert rejected.json()["review_status"] == "rejected"
        details = client.get(f"/documents/{doc_id}").json()
        assert details["extraction"] is None
        assert details["summary"] is None
        assert details["observations"] == []
        assert details["medications"] == []
        assert client.get("/profile").json()["conditions"] == []
        assert client.get("/profile/timeline").json() == []
        assert client.get("/insights").json()["trends"] == []
        assert client.post(
            f"/documents/{doc_id}/review",
            json={"decision": "confirmed"},
        ).status_code == 409


def test_review_can_correct_extracted_values_before_confirmation(monkeypatch):
    from app.routers import documents

    monkeypatch.setattr(
        documents, "classify_document", _accept_medical_document
    )
    monkeypatch.setattr(graph, "structured", lambda *a: FakeLLM(EXTRACTION))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))
    corrected = EXTRACTION.model_dump()
    corrected["lab_results"][0]["value"] = "14.8"
    corrected["medications"][0]["name"] = "Verified medicine"

    with TestClient(app, headers=_visit()) as client:
        uploaded = client.post(
            "/documents",
            files={"file": ("report.png", _png(), "image/png")},
        )
        doc_id = uploaded.json()["id"]
        response = client.post(
            f"/documents/{doc_id}/review",
            json={"decision": "confirmed", "extraction": corrected},
        )
        assert response.status_code == 200, response.text
        assert response.json()["reviewed_at"] is not None

        details = client.get(f"/documents/{doc_id}").json()
        hemoglobin = next(
            item for item in details["observations"]
            if item["display_name"] == "Haemoglobin"
        )
        assert hemoglobin["value_num"] == 14.8
        assert hemoglobin["interpretation"] == "N"
        assert details["medications"][0]["brand_name"] == "Verified medicine"
        assert details["extraction"]["lab_results"][0]["value"] == "14.8"


def test_extraction_failure_marks_failed(monkeypatch):
    from app.routers import documents
    monkeypatch.setattr(
        documents, 'classify_document', _accept_medical_document
    )
    calls = []

    class Boom(FakeLLM):
        def invoke(self, *_):
            calls.append(1)
            raise RuntimeError("api down")
    monkeypatch.setattr(graph, "structured", lambda *a: Boom(None))
    with TestClient(app, headers=_visit()) as c:
        r = c.post("/documents", files={"file": ("a.png", _png(), "image/png")})
        d = c.get(f"/documents/{r.json()['id']}").json()
        assert d["status"] == "failed" and "api down" in d["extraction"]["_error"]
        assert len(calls) == 2  # one retry, then give up


def test_digital_pdf_skips_images_and_pretranslates(monkeypatch):
    from app.routers import documents
    monkeypatch.setattr(
        documents, 'classify_document', _accept_medical_document
    )
    import pymupdf
    pdf = pymupdf.open()
    pdf.new_page().insert_textbox(pymupdf.Rect(72, 72, 520, 700), "Hemoglobin 10.8 g/dL reference 12-15 " * 10)  # digital page
    pdf.new_page()  # blank page stands in for a scan
    sent = {}

    class Spy(FakeLLM):
        def invoke(self, msgs):
            sent["kinds"] = [b["type"] for b in msgs[0].content]
            return self.out
    monkeypatch.setattr(graph, "structured", lambda *a: Spy(EXTRACTION))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))
    with TestClient(app, headers=_visit()) as c:
        c.put("/profile", json={"preferred_language": "ta"})
        r = c.post("/documents", files={"file": ("a.pdf", pdf.tobytes(), "application/pdf")})
        d = c.get(f"/documents/{r.json()['id']}").json()
        assert d["status"] == "done" and sent["kinds"] == ["text", "image"]  # only the blank page went as an image
        doc = summarize.SessionLocal().get(summarize.Document, d["id"])
        assert "ta" in doc.summary_i18n  # ready before the reader asks
        assert c.get(f"/documents/{d['id']}/summary?lang=ta").status_code == 409
        assert c.post(
            f"/documents/{d['id']}/review",
            json={"decision": "confirmed"},
        ).status_code == 200
        assert c.get(f"/documents/{d['id']}/summary?lang=ta").status_code == 200
        c.delete("/profile")


def test_visitors_are_isolated():
    with TestClient(app, headers=_visit()) as a, TestClient(app, headers=_visit()) as b:  # separate tabs
        a.put("/profile", json={"name": "Alice"})
        assert a.get("/profile").json()["name"] == "Alice"
        assert b.get("/profile").json()["name"] == "Guest"

def test_injury_timeline_is_opt_in_and_private_fields_stay_hidden(monkeypatch):
    from app.routers import documents
    monkeypatch.setattr(
        documents, 'classify_document', _accept_medical_document
    )
    injury_extraction = DocumentExtraction.model_validate({
        "doc_type": "fracture_or_injury_report",
        "doc_date": "2026-09-01",
        "fractures_or_injuries": [{
            "body_site": "wrist",
            "side": "left",
            "injury_type": "fracture",
            "date_of_injury": "2026-08-25",
            "date_of_report": "2026-08-27",
            "reported_findings": "Possible fracture; review the original report.",
            "source_text": "Left wrist fracture report",
            "confidence": 0.85
        }],
        "womens_health": {
            "pregnancy_status": "pregnant",
            "gestational_age": "12 weeks",
            "needs_clinician_review": True
        }
    })
    monkeypatch.setattr(graph, "structured", lambda *a: FakeLLM(injury_extraction))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))

    with TestClient(app, headers=_visit()) as c:
        r = c.post(
            "/documents",
            files={"file": ("injury.png", _png(), "image/png")}
        )
        assert r.status_code == 200, r.text
        doc_id = r.json()["id"]

        details = c.get(f"/documents/{doc_id}").json()
        assert details["status"] == "done", details
        assert c.post(
            f"/documents/{doc_id}/review",
            json={"decision": "confirmed"},
        ).status_code == 200

        default_items = c.get("/profile/timeline").json()
        assert not any(item["type"] == "fracture_injury" for item in default_items)
        assert not any(
            "pregnant" in str(item).lower() or "gestational_age" in str(item).lower()
            for item in default_items
        )

        injury_items = c.get("/profile/timeline?types=injuries").json()
        assert len(injury_items) == 1, injury_items
        injury = injury_items[0]
        assert injury["type"] == "fracture_injury"
        assert injury["date"] == "2026-08-25"
        assert "left" in injury["title"].lower()
        assert "wrist" in injury["title"].lower()
        assert injury["needs_clinician_review"] is True
        assert "pregnant" not in str(injury).lower()

        c.delete("/profile")

def test_injury_timeline_date_fallbacks(monkeypatch):
    from app.routers import documents
    monkeypatch.setattr(
        documents, 'classify_document', _accept_medical_document
    )
    extraction = DocumentExtraction.model_validate({
        "doc_type": "fracture_or_injury_report",
        "doc_date": "2026-09-01",
        "fractures_or_injuries": [
            {
                "body_site": "ankle",
                "side": "right",
                "injury_type": "injury",
                "date_of_injury": None,
                "date_of_report": "2026-08-27",
                "reported_findings": "Reported ankle injury.",
                "source_text": "Ankle report",
                "confidence": 0.8
            },
            {
                "body_site": "knee",
                "side": "left",
                "injury_type": "injury",
                "date_of_injury": None,
                "date_of_report": None,
                "reported_findings": "Reported knee injury.",
                "source_text": "Knee report",
                "confidence": 0.8
            }
        ]
    })
    monkeypatch.setattr(graph, "structured", lambda *a: FakeLLM(extraction))
    monkeypatch.setattr(summarize, "structured", lambda *a: FakeLLM(SUMMARY))

    with TestClient(app, headers=_visit()) as c:
        r = c.post(
            "/documents",
            files={"file": ("injuries.png", _png(), "image/png")}
        )
        assert r.status_code == 200, r.text
        doc_id = r.json()["id"]
        details = c.get(f"/documents/{doc_id}").json()
        assert details["status"] == "done", details
        assert c.post(
            f"/documents/{doc_id}/review",
            json={"decision": "confirmed"},
        ).status_code == 200

        response = c.get("/profile/timeline?types=injuries")
        assert response.status_code == 200, response.text
        items = response.json()
        dates_by_site = {
            site: item["date"]
            for item in items
            for site in ("ankle", "knee")
            if site in item["title"].lower()
        }

        assert dates_by_site["ankle"] == "2026-08-27", items
        assert dates_by_site["knee"] == "2026-09-01", items

        c.delete("/profile")


def test_nonmedical_document_is_rejected_before_storage(monkeypatch):
    from app.routers import documents

    def reject_nonmedical(*args, **kwargs):
        return DocumentClassification(
            is_medical=False,
            confidence=0.99,
            reason="The document is an electricity bill.",
        )

    monkeypatch.setattr(documents, "classify_document", reject_nonmedical)

    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/documents",
            files={"file": ("electricity.png", _png(), "image/png")},
        )

    assert response.status_code == 422
    assert "doesn't appear to be a medical document" in response.json()["detail"]


def test_uncertain_document_classification_is_rejected(monkeypatch):
    from app.routers import documents

    def uncertain(*args, **kwargs):
        return DocumentClassification(
            is_medical=True,
            confidence=0.50,
            reason="Insufficient evidence.",
        )

    monkeypatch.setattr(documents, "classify_document", uncertain)

    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/documents",
            files={"file": ("unclear.png", _png(), "image/png")},
        )

    assert response.status_code == 422
    assert "couldn't confidently identify" in response.json()["detail"]


def test_unfamiliar_medical_document_is_accepted(monkeypatch):
    from app.routers import documents

    def accept_unfamiliar_medical(*args, **kwargs):
        return DocumentClassification(
            is_medical=True,
            confidence=0.95,
            reason="A genuine medical record of an unfamiliar type.",
        )

    monkeypatch.setattr(
        documents, "classify_document", accept_unfamiliar_medical
    )

    with TestClient(app, headers=_visit()) as client:
        response = client.post(
            "/documents",
            files={"file": ("specialist-record.png", _png(), "image/png")},
        )

    assert response.status_code == 200
    assert response.json()["status"] == "processing"


def test_vitals_are_saved_per_profile_and_validated():
    with _registered_owner() as owner:
        own = owner.post(
            "/vitals",
            json={"metric": "heart_rate", "value": 72, "source": "manual"},
        )

        created = owner.post(
            "/family",
            json={"name": "Child", "pin": "123456"},
        )
        assert created.status_code == 201, created.text
        linked_profile = created.json()

        unlocked = owner.post(
            f"/family/{linked_profile['oid']}/unlock",
            json={"pin": "123456"},
        )
        assert unlocked.status_code == 200, unlocked.text

        linked = owner.post(
            f"/vitals?profile_oid={linked_profile['oid']}",
            json={
                "metric": "oxygen_saturation",
                "value": 98,
                "source": "bluetooth",
                "device_name": "Test sensor",
            },
        )
        linked_list = owner.get(f"/vitals?profile_oid={linked_profile['oid']}").json()
        owner_switch = owner.post("/family/switch-to-owner")
        assert owner_switch.status_code == 200, owner_switch.text
        own_list = owner.get("/vitals").json()
        invalid = owner.post(
            "/vitals",
            json={"metric": "heart_rate", "value": 300, "source": "manual"},
        )

    assert own.status_code == 201
    assert own.json()["unit"] == "bpm"
    assert own_list[0]["metric"] == "heart_rate"
    assert linked.status_code == 201
    assert linked.json()["unit"] == "%"
    assert linked_list[0]["device_name"] == "Test sensor"
    assert invalid.status_code == 422

    with TestClient(app, headers=_visit()) as other:
        denied = other.get(f"/vitals?profile_oid={linked_profile['oid']}")
    assert denied.status_code == 404




# Family profile PIN security regression tests.
def test_family_creation_requires_a_six_digit_numeric_pin():
    owner = _registered_owner()

    for invalid_pin in ("12345", "1234567", "12a456", "12 456"):
        response = owner.post(
            "/family",
            json={"name": "PIN Validation Test", "pin": invalid_pin},
        )
        assert response.status_code == 422, response.text

    response = owner.post(
        "/family",
        json={"name": "PIN Validation Test", "pin": "123456"},
    )
    assert response.status_code == 201, response.text


def test_family_pin_security_lockout_and_reset():
    from app.db import SessionLocal
    from app.models import Profile
    from sqlalchemy import select

    owner = _registered_owner()
    created = owner.post(
        "/family",
        json={"name": "PIN Lockout Test", "pin": "123456"},
    )
    assert created.status_code == 201, created.text
    oid = created.json()["oid"]

    for attempt in range(1, 5):
        response = owner.post(
            f"/family/{oid}/unlock",
            json={"pin": "000000"},
        )
        assert response.status_code == 401, response.text
        assert f"{5 - attempt} attempts" in response.json()["detail"]

    fifth = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "000000"},
    )
    assert fifth.status_code == 429, fifth.text
    assert "15 minutes" in fifth.json()["detail"]

    during_lockout = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "123456"},
    )
    assert during_lockout.status_code == 429, during_lockout.text

    wrong_password = owner.post(
        f"/family/{oid}/reset-pin",
        json={
            "account_password": "WrongPassword123!",
            "new_pin": "654321",
        },
    )
    assert wrong_password.status_code == 401, wrong_password.text

    reset = owner.post(
        f"/family/{oid}/reset-pin",
        json={
            "account_password": "TestPassword123!",
            "new_pin": "654321",
        },
    )
    assert reset.status_code == 200, reset.text
    assert "remains locked" in reset.json()["message"]

    old_pin = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "123456"},
    )
    assert old_pin.status_code == 401, old_pin.text

    new_pin = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "654321"},
    )
    assert new_pin.status_code == 200, new_pin.text

    with SessionLocal() as db:
        member = db.scalar(select(Profile).where(Profile.oid == oid))
        assert member is not None
        assert member.pin_failed_attempts == 0
        assert member.pin_locked_until is None


def test_legacy_family_profile_requires_owner_pin_setup_before_unlock():
    from app.db import SessionLocal
    from app.models import Profile
    from sqlalchemy import select

    owner = _registered_owner()
    created = owner.post(
        "/family",
        json={"name": "Legacy PIN Test", "pin": "123456"},
    )
    assert created.status_code == 201, created.text
    oid = created.json()["oid"]

    # Simulate a family profile created before PIN protection existed.
    with SessionLocal() as db:
        member = db.scalar(select(Profile).where(Profile.oid == oid))
        assert member is not None
        member.access_pin_hash = None
        member.pin_failed_attempts = 0
        member.pin_locked_until = None
        db.commit()

    blocked = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "123456"},
    )
    assert blocked.status_code == 409, blocked.text

    setup = owner.post(
        f"/family/{oid}/set-pin",
        json={"pin": "654321"},
    )
    assert setup.status_code == 200, setup.text

    opened = owner.post(
        f"/family/{oid}/unlock",
        json={"pin": "654321"},
    )
    assert opened.status_code == 200, opened.text


def test_family_pin_management_requires_an_account_session():
    guest = TestClient(app, headers=_visit())

    response = guest.get("/family")
    assert response.status_code == 401, response.text

    create_response = guest.post(
        "/family",
        json={"name": "Guest Family Test", "pin": "123456"},
    )
    assert create_response.status_code == 401, create_response.text
from app.models import FamilyInvitation, FamilyLink


def test_family_invitation_create_list_and_cancel():
    owner = _registered_owner()

    created = owner.post(
        "/family/invitations",
        json={
            "phone_number": "+91 98765 43210",
            "relationship_label": "Parent",
        },
    )
    assert created.status_code == 201, created.text
    invitation = created.json()
    assert invitation["status"] == "pending"
    assert invitation["phone_number"] == "+919876543210"
    assert invitation["relationship_label"] == "Parent"
    assert "No SMS was sent" in invitation["message"]

    listed = owner.get("/family/invitations")
    assert listed.status_code == 200, listed.text
    assert any(item["id"] == invitation["id"] for item in listed.json())

    cancelled = owner.delete(f"/family/invitations/{invitation['id']}")
    assert cancelled.status_code == 200, cancelled.text
    assert cancelled.json()["status"] == "cancelled"

    listed_after_cancel = owner.get("/family/invitations")
    assert listed_after_cancel.status_code == 200, listed_after_cancel.text
    saved = next(
        item for item in listed_after_cancel.json()
        if item["id"] == invitation["id"]
    )
    assert saved["status"] == "cancelled"


def test_family_invitation_rejects_invalid_phone_number():
    owner = _registered_owner()

    response = owner.post(
        "/family/invitations",
        json={"phone_number": "123"},
    )
    assert response.status_code == 422, response.text


def test_family_invitation_endpoints_require_account_session():
    guest = TestClient(app, headers=_visit())

    create_response = guest.post(
        "/family/invitations",
        json={"phone_number": "+919876543210"},
    )
    assert create_response.status_code == 401, create_response.text

    list_response = guest.get("/family/invitations")
    assert list_response.status_code == 401, list_response.text

    cancel_response = guest.delete("/family/invitations/1")
    assert cancel_response.status_code == 401, cancel_response.text
